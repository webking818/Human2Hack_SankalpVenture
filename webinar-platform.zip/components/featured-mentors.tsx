"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Star, Users, Briefcase } from "lucide-react"

// Mock data for featured mentors
const featuredMentors = [
  {
    id: 1,
    name: "Dr. Vikram Mehta",
    title: "Serial Entrepreneur & Angel Investor",
    bio: "Founded 3 successful startups with 2 exits. Now mentoring early-stage founders in tech and sustainability.",
    expertise: ["Startup Growth", "Fundraising", "Product Strategy"],
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.9,
    mentees: 47,
    experience: "15+ years",
  },
  {
    id: 2,
    name: "Neha Kapoor",
    title: "FinTech Executive & Startup Advisor",
    bio: "Former CTO at PayEase. Specializes in helping fintech startups scale their technology and operations.",
    expertise: ["FinTech", "Technology Scaling", "Product Development"],
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.8,
    mentees: 32,
    experience: "12+ years",
  },
  {
    id: 3,
    name: "Rajiv Khanna",
    title: "Marketing Strategist & Growth Hacker",
    bio: "Helped 50+ startups achieve product-market fit and scale their customer acquisition strategies.",
    expertise: ["Growth Marketing", "Brand Strategy", "Market Entry"],
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.7,
    mentees: 65,
    experience: "10+ years",
  },
  {
    id: 4,
    name: "Dr. Lakshmi Iyer",
    title: "Social Entrepreneurship Expert",
    bio: "Founded two social enterprises addressing education and healthcare in rural India. PhD in Social Innovation.",
    expertise: ["Social Impact", "Sustainable Business Models", "Rural Innovation"],
    avatar: "/placeholder.svg?height=100&width=100",
    rating: 4.9,
    mentees: 38,
    experience: "14+ years",
  },
]

export default function FeaturedMentors() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {featuredMentors.map((mentor) => (
        <Card key={mentor.id} className="h-full flex flex-col">
          <CardHeader className="text-center pb-2">
            <Avatar className="h-20 w-20 mx-auto mb-3">
              <AvatarImage src={mentor.avatar} alt={mentor.name} />
              <AvatarFallback>
                {mentor.name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")}
              </AvatarFallback>
            </Avatar>
            <CardTitle className="text-lg">{mentor.name}</CardTitle>
            <CardDescription>{mentor.title}</CardDescription>
          </CardHeader>
          <CardContent className="flex-grow">
            <div className="flex justify-between items-center mb-3 text-sm">
              <div className="flex items-center">
                <Star className="h-4 w-4 text-yellow-500 mr-1" />
                <span>{mentor.rating}</span>
              </div>
              <div className="flex items-center">
                <Users className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-muted-foreground">{mentor.mentees} mentees</span>
              </div>
              <div className="flex items-center">
                <Briefcase className="h-4 w-4 mr-1 text-muted-foreground" />
                <span className="text-muted-foreground">{mentor.experience}</span>
              </div>
            </div>
            <p className="text-sm text-muted-foreground line-clamp-3 mb-3">{mentor.bio}</p>
            <div className="flex flex-wrap gap-1">
              {mentor.expertise.map((skill) => (
                <Badge key={skill} variant="outline" className="text-xs">
                  {skill}
                </Badge>
              ))}
            </div>
          </CardContent>
          <CardFooter className="pt-2">
            <Link href={`/mentors/${mentor.id}`} className="w-full">
              <Button variant="outline" size="sm" className="w-full">
                Connect
              </Button>
            </Link>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

