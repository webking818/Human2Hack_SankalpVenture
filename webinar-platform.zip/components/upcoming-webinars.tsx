"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { Calendar, Clock, Users } from "lucide-react"

// Mock data for upcoming webinars
const upcomingWebinars = [
  {
    id: 1,
    title: "From Idea to MVP: Building Your First Prototype",
    description: "Learn how to validate your idea and build a minimum viable product with limited resources.",
    date: "2025-04-15T14:00:00",
    duration: 90, // minutes
    category: "Product Development",
    speaker: {
      name: "Arjun Malhotra",
      title: "Product Lead at InnovateX",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    attendees: 245,
  },
  {
    id: 2,
    title: "Fundraising Strategies for Early-Stage Startups",
    description: "Discover effective approaches to raise capital for your startup in the current funding environment.",
    date: "2025-04-18T10:00:00",
    duration: 60, // minutes
    category: "Fundraising",
    speaker: {
      name: "Sonia Agarwal",
      title: "Partner at Elevation Capital",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    attendees: 312,
  },
  {
    id: 3,
    title: "Building a Sustainable Business Model",
    description: "Learn how to create a business model that balances profit with environmental and social impact.",
    date: "2025-04-22T16:00:00",
    duration: 75, // minutes
    category: "Sustainability",
    speaker: {
      name: "Dr. Vikram Mehta",
      title: "Serial Entrepreneur & Angel Investor",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    attendees: 189,
  },
]

export default function UpcomingWebinars() {
  return (
    <div className="space-y-4">
      {upcomingWebinars.map((webinar) => (
        <Card key={webinar.id}>
          <CardHeader className="pb-2">
            <div className="flex justify-between items-start">
              <Badge>{webinar.category}</Badge>
              <div className="text-sm text-muted-foreground">
                {new Date(webinar.date).toLocaleDateString("en-US", {
                  month: "short",
                  day: "numeric",
                  year: "numeric",
                })}
              </div>
            </div>
            <CardTitle className="mt-2">{webinar.title}</CardTitle>
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={webinar.speaker.avatar} alt={webinar.speaker.name} />
                <AvatarFallback>{webinar.speaker.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <CardDescription>
                {webinar.speaker.name}, {webinar.speaker.title}
              </CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">{webinar.description}</p>
            <div className="flex flex-wrap gap-6 mt-4 text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span>
                  {new Date(webinar.date).toLocaleDateString("en-US", {
                    weekday: "short",
                    month: "short",
                    day: "numeric",
                  })}
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Clock className="h-4 w-4 text-muted-foreground" />
                <span>
                  {new Date(webinar.date).toLocaleTimeString("en-US", {
                    hour: "numeric",
                    minute: "2-digit",
                    hour12: true,
                  })}
                  {" • "}
                  {webinar.duration} min
                </span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-muted-foreground" />
                <span>{webinar.attendees} attending</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="flex justify-end gap-3">
            <Link href={`/webinars/${webinar.id}/questions`}>
              <Button variant="outline" size="sm">
                Submit Questions
              </Button>
            </Link>
            <Link href={`/webinars/${webinar.id}`}>
              <Button size="sm">Register</Button>
            </Link>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

