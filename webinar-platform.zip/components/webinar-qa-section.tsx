"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ThumbsUp, MessageSquare, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import { analyzeQuestion } from "@/lib/question-analyzer"

interface Question {
  id: string
  text: string
  user: string
  timestamp: string
  votes: number
  isGeneralized: boolean
  category?: string
  answers?: Answer[]
}

interface Answer {
  id: string
  text: string
  user: string
  timestamp: string
  isFromSpeaker: boolean
}

// Mock data for questions
const mockQuestions: Question[] = [
  {
    id: "q1",
    text: "What are the most important metrics to track for machine learning models?",
    user: "Alex Chen",
    timestamp: "2025-03-20T14:30:00",
    votes: 24,
    isGeneralized: true,
    category: "Model Evaluation",
    answers: [
      {
        id: "a1",
        text: "Great question! The most important metrics depend on your specific task. For classification, consider accuracy, precision, recall, F1-score, and AUC-ROC. For regression, look at MSE, RMSE, MAE, and R-squared. Always consider both training and validation metrics to detect overfitting.",
        user: "Dr. Jane Smith",
        timestamp: "2025-03-21T09:15:00",
        isFromSpeaker: true,
      },
    ],
  },
  {
    id: "q2",
    text: "How do you handle imbalanced datasets in machine learning?",
    user: "Maria Rodriguez",
    timestamp: "2025-03-19T16:45:00",
    votes: 18,
    isGeneralized: true,
    category: "Data Preparation",
    answers: [],
  },
  {
    id: "q3",
    text: "What's the difference between supervised and unsupervised learning?",
    user: "James Wilson",
    timestamp: "2025-03-18T11:20:00",
    votes: 15,
    isGeneralized: true,
    category: "Fundamentals",
    answers: [
      {
        id: "a2",
        text: "Supervised learning uses labeled data where the algorithm learns to map inputs to known outputs. Examples include classification and regression. Unsupervised learning works with unlabeled data to find patterns or structure, like clustering or dimensionality reduction.",
        user: "Dr. Jane Smith",
        timestamp: "2025-03-18T14:30:00",
        isFromSpeaker: true,
      },
    ],
  },
]

export default function WebinarQASection({ webinarId }: { webinarId: string }) {
  const [questions, setQuestions] = useState<Question[]>(mockQuestions)
  const [newQuestion, setNewQuestion] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [similarQuestions, setSimilarQuestions] = useState<Question[]>([])
  const [showSimilar, setShowSimilar] = useState(false)

  const handleQuestionChange = async (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setNewQuestion(value)

    // Only analyze if there's substantial content
    if (value.length > 20) {
      try {
        // This would call the AI analysis in a real implementation
        const similar = await analyzeQuestion(value, questions)
        setSimilarQuestions(similar)
        setShowSimilar(similar.length > 0)
      } catch (error) {
        console.error("Error analyzing question:", error)
      }
    } else {
      setShowSimilar(false)
    }
  }

  const handleSubmitQuestion = async () => {
    if (!newQuestion.trim()) return

    setIsSubmitting(true)

    try {
      // In a real implementation, this would send the question to the backend
      // and use AI to analyze and potentially generalize it
      const newQuestionObj: Question = {
        id: `q${Date.now()}`,
        text: newQuestion,
        user: "Current User",
        timestamp: new Date().toISOString(),
        votes: 1,
        isGeneralized: false,
      }

      setQuestions([newQuestionObj, ...questions])
      setNewQuestion("")
      setShowSimilar(false)
    } catch (error) {
      console.error("Error submitting question:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleVote = (questionId: string) => {
    setQuestions(questions.map((q) => (q.id === questionId ? { ...q, votes: q.votes + 1 } : q)))
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-semibold mb-4">Questions & Answers</h2>
        <p className="text-muted-foreground mb-6">
          Ask your questions before or during the webinar. Our AI will analyze and group similar questions to ensure all
          topics are covered.
        </p>

        <div className="space-y-4">
          <Textarea
            placeholder="What would you like to ask the speaker?"
            className="min-h-[100px]"
            value={newQuestion}
            onChange={handleQuestionChange}
          />

          {showSimilar && (
            <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950 dark:border-amber-800">
              <CardHeader className="py-3">
                <div className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                  <CardTitle className="text-base text-amber-800 dark:text-amber-300">
                    Similar questions found
                  </CardTitle>
                </div>
                <CardDescription className="text-amber-700 dark:text-amber-400">
                  These questions are similar to yours and may already have answers:
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 py-0">
                {similarQuestions.map((q) => (
                  <div key={q.id} className="border-l-2 border-amber-300 dark:border-amber-700 pl-3">
                    <p className="font-medium text-amber-900 dark:text-amber-300">{q.text}</p>
                    {q.answers && q.answers.length > 0 && (
                      <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                        This question has {q.answers.length} answer{q.answers.length > 1 ? "s" : ""}
                      </p>
                    )}
                  </div>
                ))}
              </CardContent>
            </Card>
          )}

          <div className="flex justify-end">
            <Button onClick={handleSubmitQuestion} disabled={isSubmitting || !newQuestion.trim()}>
              Submit Question
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="popular">
        <TabsList>
          <TabsTrigger value="popular">Most Popular</TabsTrigger>
          <TabsTrigger value="recent">Recent</TabsTrigger>
          <TabsTrigger value="answered">Answered</TabsTrigger>
        </TabsList>

        <TabsContent value="popular" className="space-y-4 mt-4">
          {questions
            .sort((a, b) => b.votes - a.votes)
            .map((question) => (
              <QuestionCard key={question.id} question={question} onVote={handleVote} />
            ))}
        </TabsContent>

        <TabsContent value="recent" className="space-y-4 mt-4">
          {questions
            .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
            .map((question) => (
              <QuestionCard key={question.id} question={question} onVote={handleVote} />
            ))}
        </TabsContent>

        <TabsContent value="answered" className="space-y-4 mt-4">
          {questions
            .filter((q) => q.answers && q.answers.length > 0)
            .map((question) => (
              <QuestionCard key={question.id} question={question} onVote={handleVote} />
            ))}
        </TabsContent>
      </Tabs>
    </div>
  )
}

function QuestionCard({
  question,
  onVote,
}: {
  question: Question
  onVote: (id: string) => void
}) {
  const [expanded, setExpanded] = useState(false)

  const formattedDate = new Date(question.timestamp).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between">
          <div className="flex items-start gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="flex flex-col items-center p-0 h-auto"
              onClick={() => onVote(question.id)}
            >
              <ThumbsUp className="h-4 w-4 mb-1" />
              <span className="text-xs font-medium">{question.votes}</span>
            </Button>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-medium">{question.user}</span>
                <span className="text-xs text-muted-foreground">{formattedDate}</span>
                {question.isGeneralized && (
                  <Badge variant="outline" className="text-xs">
                    Generalized
                  </Badge>
                )}
                {question.category && (
                  <Badge variant="secondary" className="text-xs">
                    {question.category}
                  </Badge>
                )}
              </div>
              <CardTitle className="text-base font-medium">{question.text}</CardTitle>
            </div>
          </div>

          {question.answers && question.answers.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1"
            >
              <MessageSquare className="h-4 w-4" />
              <span className="text-xs">{question.answers.length}</span>
            </Button>
          )}
        </div>
      </CardHeader>

      {expanded && question.answers && question.answers.length > 0 && (
        <CardContent className="pt-0">
          <div className="border-t pt-3 space-y-4">
            {question.answers.map((answer) => (
              <div key={answer.id} className="pl-4 border-l-2 border-primary">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium">{answer.user}</span>
                  {answer.isFromSpeaker && <Badge className="text-xs">Speaker</Badge>}
                  <span className="text-xs text-muted-foreground">
                    {new Date(answer.timestamp).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                </div>
                <p className="text-sm">{answer.text}</p>
              </div>
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  )
}

