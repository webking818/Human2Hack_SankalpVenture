"use client"

import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { Clock } from "lucide-react"

// Mock data for AI-recommended news
const newsRecommendations = [
  {
    id: 1,
    title: "Indian Startups Raised $2.8B in Q1 2025, Report Shows",
    source: "Startup Daily",
    category: "Funding",
    timeAgo: "2 hours ago",
    url: "/news/1",
  },
  {
    id: 2,
    title: "New Government Policy to Boost Rural Entrepreneurship",
    source: "Economic Times",
    category: "Policy",
    timeAgo: "5 hours ago",
    url: "/news/2",
  },
  {
    id: 3,
    title: "Sustainable Startups: The New Favorite for Venture Capital",
    source: "Business Insider",
    category: "Sustainability",
    timeAgo: "1 day ago",
    url: "/news/3",
  },
  {
    id: 4,
    title: "AI Tools Every Entrepreneur Should Be Using in 2025",
    source: "Tech Crunch",
    category: "Technology",
    timeAgo: "1 day ago",
    url: "/news/4",
  },
  {
    id: 5,
    title: "How This 25-Year-Old Built a Rs 50 Crore Business in 2 Years",
    source: "Entrepreneur India",
    category: "Success Story",
    timeAgo: "2 days ago",
    url: "/news/5",
  },
]

export default function NewsRecommendations() {
  return (
    <div className="space-y-4">
      {newsRecommendations.map((news) => (
        <Link key={news.id} href={news.url}>
          <Card className="hover:bg-muted/50 transition-colors">
            <CardHeader className="py-3">
              <div className="flex justify-between items-start">
                <Badge variant="outline">{news.category}</Badge>
                <div className="flex items-center text-xs text-muted-foreground">
                  <Clock className="h-3 w-3 mr-1" />
                  {news.timeAgo}
                </div>
              </div>
              <CardTitle className="text-base mt-2">{news.title}</CardTitle>
              <CardDescription className="text-xs">{news.source}</CardDescription>
            </CardHeader>
          </Card>
        </Link>
      ))}
    </div>
  )
}

