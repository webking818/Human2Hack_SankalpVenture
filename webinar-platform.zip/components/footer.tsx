import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t mt-12">
      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="font-bold text-lg mb-4">Sankalp Venture</h3>
            <p className="text-muted-foreground text-sm">
              Connecting entrepreneurs, mentors, and resources to help turn innovative ideas into successful ventures.
            </p>
          </div>

          <div>
            <h4 className="font-medium mb-4">Platform</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/projects" className="text-sm text-muted-foreground hover:text-foreground">
                  Explore Projects
                </Link>
              </li>
              <li>
                <Link href="/mentors" className="text-sm text-muted-foreground hover:text-foreground">
                  Find Mentors
                </Link>
              </li>
              <li>
                <Link href="/challenges" className="text-sm text-muted-foreground hover:text-foreground">
                  Take Challenges
                </Link>
              </li>
              <li>
                <Link href="/webinars" className="text-sm text-muted-foreground hover:text-foreground">
                  Join Webinars
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Resources</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/news" className="text-sm text-muted-foreground hover:text-foreground">
                  News & Articles
                </Link>
              </li>
              <li>
                <Link href="/learning" className="text-sm text-muted-foreground hover:text-foreground">
                  Learning Center
                </Link>
              </li>
              <li>
                <Link href="/success-stories" className="text-sm text-muted-foreground hover:text-foreground">
                  Success Stories
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-sm text-muted-foreground hover:text-foreground">
                  FAQ
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-medium mb-4">Company</h4>
            <ul className="space-y-2">
              <li>
                <Link href="/about" className="text-sm text-muted-foreground hover:text-foreground">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-sm text-muted-foreground hover:text-foreground">
                  Contact
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-muted-foreground hover:text-foreground">
                  Terms of Service
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t mt-8 pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Sankalp Venture. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}

