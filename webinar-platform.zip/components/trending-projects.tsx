"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import Link from "next/link"
import { ThumbsUp, MessageSquare, Eye } from "lucide-react"

// Mock data for trending projects
const trendingProjects = [
  {
    id: 1,
    title: "EcoTrack: Sustainable Supply Chain Monitoring",
    description: "A blockchain-based platform to track and verify sustainable practices across supply chains.",
    category: "Sustainability",
    tags: ["Blockchain", "Supply Chain", "Environment"],
    author: {
      name: "Priya Sharma",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    likes: 128,
    comments: 47,
    views: 1243,
  },
  {
    id: 2,
    title: "FinLit: Financial Literacy for Gen Z",
    description: "Mobile app that gamifies financial education for young adults with personalized learning paths.",
    category: "FinTech",
    tags: ["Education", "Mobile App", "Finance"],
    author: {
      name: "Rahul Patel",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    likes: 96,
    comments: 32,
    views: 876,
  },
  {
    id: 3,
    title: "RuralConnect: Marketplace for Village Artisans",
    description: "Platform connecting rural artisans directly with global markets, eliminating middlemen.",
    category: "E-Commerce",
    tags: ["Rural Development", "Marketplace", "Artisans"],
    author: {
      name: "Ananya Singh",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    likes: 152,
    comments: 58,
    views: 1567,
  },
]

export default function TrendingProjects() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {trendingProjects.map((project) => (
        <Card key={project.id} className="h-full flex flex-col">
          <CardHeader>
            <div className="flex justify-between items-start">
              <Badge>{project.category}</Badge>
              <div className="flex items-center text-sm text-muted-foreground">
                <Eye className="h-4 w-4 mr-1" />
                {project.views}
              </div>
            </div>
            <CardTitle className="mt-2 line-clamp-2">{project.title}</CardTitle>
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={project.author.avatar} alt={project.author.name} />
                <AvatarFallback>{project.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <CardDescription>{project.author.name}</CardDescription>
            </div>
          </CardHeader>
          <CardContent className="flex-grow">
            <p className="text-muted-foreground line-clamp-3">{project.description}</p>
            <div className="flex flex-wrap gap-2 mt-4">
              {project.tags.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
          </CardContent>
          <CardFooter className="flex justify-between border-t pt-4">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <ThumbsUp className="h-4 w-4" />
                {project.likes}
              </div>
              <div className="flex items-center gap-1 text-sm text-muted-foreground">
                <MessageSquare className="h-4 w-4" />
                {project.comments}
              </div>
            </div>
            <Link href={`/projects/${project.id}`}>
              <Button variant="outline" size="sm">
                View Project
              </Button>
            </Link>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

