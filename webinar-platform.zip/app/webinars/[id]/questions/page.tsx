"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ThumbsUp, MessageSquare, AlertCircle, ArrowLeft } from "lucide-react"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { analyzeQuestion } from "@/lib/question-analyzer"

interface Question {
  id: string
  text: string
  user: string
  timestamp: string
  votes: number
  isGeneralized: boolean
  category?: string
  answers?: Answer[]
}

interface Answer {
  id: string
  text: string
  user: string
  timestamp: string
  isFromSpeaker: boolean
}

// Mock data for webinar
const webinar = {
  id: "1",
  title: "From Idea to MVP: Building Your First Prototype",
  speaker: "Arjun Malhotra",
  date: "2025-04-15T14:00:00",
}

// Mock data for questions
const mockQuestions: Question[] = [
  {
    id: "q1",
    text: "What are the most cost-effective ways to validate a business idea before building an MVP?",
    user: "Rahul Sharma",
    timestamp: "2025-03-20T14:30:00",
    votes: 24,
    isGeneralized: true,
    category: "Idea Validation",
    answers: [
      {
        id: "a1",
        text: "Great question! Some cost-effective validation methods include: 1) Customer interviews to understand pain points, 2) Landing page tests to gauge interest, 3) Competitor analysis, 4) Online surveys, and 5) Paper prototypes or wireframes to get early feedback. The key is to gather real user insights before investing in development.",
        user: "Arjun Malhotra",
        timestamp: "2025-03-21T09:15:00",
        isFromSpeaker: true,
      },
    ],
  },
  {
    id: "q2",
    text: "How do you decide which features to include in an MVP and which to leave for later iterations?",
    user: "Priya Patel",
    timestamp: "2025-03-19T16:45:00",
    votes: 18,
    isGeneralized: true,
    category: "Feature Prioritization",
    answers: [],
  },
  {
    id: "q3",
    text: "What tools would you recommend for building prototypes with limited technical knowledge?",
    user: "Vikram Singh",
    timestamp: "2025-03-18T11:20:00",
    votes: 15,
    isGeneralized: true,
    category: "Tools & Resources",
    answers: [
      {
        id: "a2",
        text: "For non-technical founders, I recommend no-code tools like Bubble, Webflow, or Adalo for app prototypes. For simpler mockups, Figma or Adobe XD are excellent. You can also use Zapier to connect different services. The goal is to demonstrate your core value proposition without writing code.",
        user: "Arjun Malhotra",
        timestamp: "2025-03-18T14:30:00",
        isFromSpeaker: true,
      },
    ],
  },
]

export default function WebinarQuestionsPage({ params }: { params: { id: string } }) {
  const [questions, setQuestions] = useState<Question[]>(mockQuestions)
  const [newQuestion, setNewQuestion] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [similarQuestions, setSimilarQuestions] = useState<Question[]>([])
  const [showSimilar, setShowSimilar] = useState(false)

  const handleQuestionChange = async (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const value = e.target.value
    setNewQuestion(value)

    // Only analyze if there's substantial content
    if (value.length > 20) {
      try {
        // This would call the AI analysis in a real implementation
        const similar = await analyzeQuestion(value, questions)
        setSimilarQuestions(similar)
        setShowSimilar(similar.length > 0)
      } catch (error) {
        console.error("Error analyzing question:", error)
      }
    } else {
      setShowSimilar(false)
    }
  }

  const handleSubmitQuestion = async () => {
    if (!newQuestion.trim()) return

    setIsSubmitting(true)

    try {
      // In a real implementation, this would send the question to the backend
      // and use AI to analyze and potentially generalize it
      const newQuestionObj: Question = {
        id: `q${Date.now()}`,
        text: newQuestion,
        user: "Current User",
        timestamp: new Date().toISOString(),
        votes: 1,
        isGeneralized: false,
      }

      setQuestions([newQuestionObj, ...questions])
      setNewQuestion("")
      setShowSimilar(false)
    } catch (error) {
      console.error("Error submitting question:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const handleVote = (questionId: string) => {
    setQuestions(questions.map((q) => (q.id === questionId ? { ...q, votes: q.votes + 1 } : q)))
  }

  const formattedDate = new Date(webinar.date).toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  })

  return (
    <div className="container mx-auto px-4 py-8">
      <Link
        href={`/webinars/${params.id}`}
        className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to webinar details
      </Link>

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">{webinar.title}</h1>
        <p className="text-muted-foreground">
          Submit your questions for the webinar with {webinar.speaker} on {formattedDate}
        </p>
      </div>

      <div className="space-y-6 max-w-3xl mx-auto">
        <div>
          <h2 className="text-2xl font-semibold mb-4">Ask Your Question</h2>
          <p className="text-muted-foreground mb-6">
            Our AI will analyze your question and group similar ones to ensure all topics are covered during the
            webinar.
          </p>

          <div className="space-y-4">
            <Textarea
              placeholder="What would you like to ask the speaker?"
              className="min-h-[100px]"
              value={newQuestion}
              onChange={handleQuestionChange}
            />

            {showSimilar && (
              <Card className="border-amber-200 bg-amber-50 dark:bg-amber-950 dark:border-amber-800">
                <CardHeader className="py-3">
                  <div className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                    <CardTitle className="text-base text-amber-800 dark:text-amber-300">
                      Similar questions found
                    </CardTitle>
                  </div>
                  <CardDescription className="text-amber-700 dark:text-amber-400">
                    These questions are similar to yours and may already have answers:
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-3 py-0">
                  {similarQuestions.map((q) => (
                    <div key={q.id} className="border-l-2 border-amber-300 dark:border-amber-700 pl-3">
                      <p className="font-medium text-amber-900 dark:text-amber-300">{q.text}</p>
                      {q.answers && q.answers.length > 0 && (
                        <p className="text-sm text-amber-700 dark:text-amber-400 mt-1">
                          This question has {q.answers.length} answer{q.answers.length > 1 ? "s" : ""}
                        </p>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}

            <div className="flex justify-end">
              <Button onClick={handleSubmitQuestion} disabled={isSubmitting || !newQuestion.trim()}>
                Submit Question
              </Button>
            </div>
          </div>
        </div>

        <div className="border-t pt-8">
          <h2 className="text-2xl font-semibold mb-4">Questions from the Community</h2>

          <Tabs defaultValue="popular">
            <TabsList>
              <TabsTrigger value="popular">Most Popular</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="answered">Answered</TabsTrigger>
            </TabsList>

            <TabsContent value="popular" className="space-y-4 mt-4">
              {questions
                .sort((a, b) => b.votes - a.votes)
                .map((question) => (
                  <QuestionCard key={question.id} question={question} onVote={handleVote} />
                ))}
            </TabsContent>

            <TabsContent value="recent" className="space-y-4 mt-4">
              {questions
                .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
                .map((question) => (
                  <QuestionCard key={question.id} question={question} onVote={handleVote} />
                ))}
            </TabsContent>

            <TabsContent value="answered" className="space-y-4 mt-4">
              {questions
                .filter((q) => q.answers && q.answers.length > 0)
                .map((question) => (
                  <QuestionCard key={question.id} question={question} onVote={handleVote} />
                ))}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}

function QuestionCard({
  question,
  onVote,
}: {
  question: Question
  onVote: (id: string) => void
}) {
  const [expanded, setExpanded] = useState(false)

  const formattedDate = new Date(question.timestamp).toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  })

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between">
          <div className="flex items-start gap-3">
            <Button
              variant="ghost"
              size="sm"
              className="flex flex-col items-center p-0 h-auto"
              onClick={() => onVote(question.id)}
            >
              <ThumbsUp className="h-4 w-4 mb-1" />
              <span className="text-xs font-medium">{question.votes}</span>
            </Button>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="text-sm font-medium">{question.user}</span>
                <span className="text-xs text-muted-foreground">{formattedDate}</span>
                {question.isGeneralized && (
                  <Badge variant="outline" className="text-xs">
                    Generalized
                  </Badge>
                )}
                {question.category && (
                  <Badge variant="secondary" className="text-xs">
                    {question.category}
                  </Badge>
                )}
              </div>
              <CardTitle className="text-base font-medium">{question.text}</CardTitle>
            </div>
          </div>

          {question.answers && question.answers.length > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setExpanded(!expanded)}
              className="flex items-center gap-1"
            >
              <MessageSquare className="h-4 w-4" />
              <span className="text-xs">{question.answers.length}</span>
            </Button>
          )}
        </div>
      </CardHeader>

      {expanded && question.answers && question.answers.length > 0 && (
        <CardContent className="pt-0">
          <div className="border-t pt-3 space-y-4">
            {question.answers.map((answer) => (
              <div key={answer.id} className="pl-4 border-l-2 border-primary">
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-sm font-medium">{answer.user}</span>
                  {answer.isFromSpeaker && <Badge className="text-xs">Speaker</Badge>}
                  <span className="text-xs text-muted-foreground">
                    {new Date(answer.timestamp).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </span>
                </div>
                <p className="text-sm">{answer.text}</p>
              </div>
            ))}
          </div>
        </CardContent>
      )}
    </Card>
  )
}

