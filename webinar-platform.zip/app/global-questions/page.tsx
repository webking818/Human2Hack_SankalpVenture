import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Search, ThumbsUp, ExternalLink } from "lucide-react"
import Link from "next/link"

// Mock data for global questions
const globalQuestions = [
  {
    id: "gq1",
    question: "What's the difference between supervised and unsupervised learning?",
    category: "Machine Learning",
    votes: 87,
    askedBy: "Multiple Users",
    relatedWebinars: [
      { id: "1", title: "Machine Learning Fundamentals", date: "2025-04-15" },
      { id: "5", title: "AI for Beginners", date: "2025-05-10" },
    ],
    answered: true,
  },
  {
    id: "gq2",
    question: "How can I measure the ROI of my social media marketing campaigns?",
    category: "Digital Marketing",
    votes: 64,
    askedBy: "Multiple Users",
    relatedWebinars: [
      { id: "2", title: "Digital Marketing Strategies for 2025", date: "2025-04-18" },
      { id: "7", title: "Social Media ROI Masterclass", date: "2025-05-22" },
    ],
    answered: true,
  },
  {
    id: "gq3",
    question: "What are the best practices for financial planning in early-stage startups?",
    category: "Finance",
    votes: 52,
    askedBy: "Multiple Users",
    relatedWebinars: [{ id: "3", title: "Financial Planning for Entrepreneurs", date: "2025-04-20" }],
    answered: false,
  },
  {
    id: "gq4",
    question: "How do I implement server-side rendering in Next.js?",
    category: "Web Development",
    votes: 49,
    askedBy: "Multiple Users",
    relatedWebinars: [{ id: "4", title: "Web Development with Next.js", date: "2025-04-22" }],
    answered: true,
  },
  {
    id: "gq5",
    question: "What are the key differences between traditional marketing and growth hacking?",
    category: "Marketing",
    votes: 41,
    askedBy: "Multiple Users",
    relatedWebinars: [{ id: "2", title: "Digital Marketing Strategies for 2025", date: "2025-04-18" }],
    answered: false,
  },
]

// Categories for filtering
const categories = ["All", "Technology", "Marketing", "Finance", "Web Development", "Machine Learning"]

export default function GlobalQuestionsPage() {
  return (
    <main className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Global Questions</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Browse questions asked across all webinars or ask your own. We'll connect you with relevant webinars and
          answers.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-4 max-w-3xl mx-auto mb-12">
        <div className="relative flex-grow">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
          <Input placeholder="Search questions by topic or keyword" className="pl-10" />
        </div>
        <Button>Search</Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Ask a Question</CardTitle>
              <CardDescription>
                Can't find what you're looking for? Ask a new question and we'll connect you with relevant webinars.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button className="w-full">Ask a New Question</Button>
            </CardContent>
          </Card>

          <div className="mt-6">
            <h3 className="font-medium mb-3">Filter by Category</h3>
            <div className="space-y-2">
              {categories.map((category) => (
                <div key={category} className="flex items-center">
                  <input
                    type="checkbox"
                    id={`category-${category}`}
                    className="mr-2"
                    defaultChecked={category === "All"}
                  />
                  <label htmlFor={`category-${category}`}>{category}</label>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <h3 className="font-medium mb-3">Filter by Status</h3>
            <div className="space-y-2">
              <div className="flex items-center">
                <input type="checkbox" id="status-all" className="mr-2" defaultChecked />
                <label htmlFor="status-all">All Questions</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="status-answered" className="mr-2" />
                <label htmlFor="status-answered">Answered Only</label>
              </div>
              <div className="flex items-center">
                <input type="checkbox" id="status-unanswered" className="mr-2" />
                <label htmlFor="status-unanswered">Unanswered Only</label>
              </div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="popular">
            <TabsList className="mb-6">
              <TabsTrigger value="popular">Most Popular</TabsTrigger>
              <TabsTrigger value="recent">Recent</TabsTrigger>
              <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
            </TabsList>

            <TabsContent value="popular" className="space-y-4">
              {globalQuestions
                .sort((a, b) => b.votes - a.votes)
                .map((question) => (
                  <GlobalQuestionCard key={question.id} question={question} />
                ))}
            </TabsContent>

            <TabsContent value="recent" className="space-y-4">
              {/* In a real app, this would be sorted by date */}
              {globalQuestions.map((question) => (
                <GlobalQuestionCard key={question.id} question={question} />
              ))}
            </TabsContent>

            <TabsContent value="unanswered" className="space-y-4">
              {globalQuestions
                .filter((q) => !q.answered)
                .map((question) => (
                  <GlobalQuestionCard key={question.id} question={question} />
                ))}
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </main>
  )
}

function GlobalQuestionCard({ question }: { question: any }) {
  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between">
          <div className="flex items-start gap-3">
            <div className="flex flex-col items-center p-0">
              <ThumbsUp className="h-4 w-4 mb-1 text-muted-foreground" />
              <span className="text-xs font-medium">{question.votes}</span>
            </div>

            <div>
              <div className="flex items-center gap-2 mb-1">
                <Badge>{question.category}</Badge>
                {question.answered ? (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    Answered
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    Awaiting Answer
                  </Badge>
                )}
              </div>
              <CardTitle className="text-base font-medium">{question.question}</CardTitle>
              <CardDescription className="mt-1">Asked by {question.askedBy}</CardDescription>
            </div>
          </div>
        </div>
      </CardHeader>

      <CardContent className="pt-0">
        <div className="border-t pt-3">
          <h4 className="text-sm font-medium mb-2">Related Webinars:</h4>
          <div className="space-y-2">
            {question.relatedWebinars.map((webinar: any) => (
              <Link
                key={webinar.id}
                href={`/webinar/${webinar.id}`}
                className="flex items-center justify-between p-2 rounded-md bg-muted hover:bg-muted/80 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium">{webinar.title}</p>
                  <p className="text-xs text-muted-foreground">
                    {new Date(webinar.date).toLocaleDateString("en-US", {
                      month: "short",
                      day: "numeric",
                      year: "numeric",
                    })}
                  </p>
                </div>
                <ExternalLink className="h-4 w-4 text-muted-foreground" />
              </Link>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

