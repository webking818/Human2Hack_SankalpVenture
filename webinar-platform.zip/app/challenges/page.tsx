"use client"

import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Trophy, Clock, Users, Award, Star } from "lucide-react"
import Link from "next/link"

// Mock data for challenges
const challenges = [
  {
    id: 1,
    title: "Startup Fundamentals Quiz",
    description: "Test your knowledge on business models, market validation, and startup basics.",
    category: "Business",
    difficulty: "Beginner",
    questions: 20,
    timeLimit: 15, // minutes
    participants: 1245,
    perks: ["50 Venture Points", "Beginner Entrepreneur Badge", "Access to exclusive resources"],
    expiresIn: "5 days",
  },
  {
    id: 2,
    title: "Financial Literacy Challenge",
    description: "Prove your expertise in startup finance, funding, and investment strategies.",
    category: "Finance",
    difficulty: "Intermediate",
    questions: 25,
    timeLimit: 20, // minutes
    participants: 876,
    perks: ["100 Venture Points", "Finance Expert Badge", "1:1 session with a financial mentor"],
    expiresIn: "3 days",
  },
  {
    id: 3,
    title: "Product Development Mastery",
    description: "Challenge yourself on product design, development methodologies, and user experience.",
    category: "Product",
    difficulty: "Advanced",
    questions: 30,
    timeLimit: 25, // minutes
    participants: 542,
    perks: ["150 Venture Points", "Product Guru Badge", "Featured profile for 1 week"],
    expiresIn: "7 days",
  },
  {
    id: 4,
    title: "Marketing Strategy Sprint",
    description: "Test your knowledge of digital marketing, customer acquisition, and growth tactics.",
    category: "Marketing",
    difficulty: "Intermediate",
    questions: 25,
    timeLimit: 20, // minutes
    participants: 923,
    perks: ["100 Venture Points", "Marketing Strategist Badge", "Free marketing toolkit"],
    expiresIn: "2 days",
  },
]

// Mock data for leaderboard
const leaderboard = [
  { rank: 1, name: "Vikram Mehta", points: 2450, badges: 12 },
  { rank: 2, name: "Priya Sharma", points: 2340, badges: 10 },
  { rank: 3, name: "Rahul Patel", points: 2180, badges: 11 },
  { rank: 4, name: "Ananya Singh", points: 2050, badges: 9 },
  { rank: 5, name: "Arjun Kumar", points: 1980, badges: 8 },
  { rank: 6, name: "Neha Gupta", points: 1920, badges: 9 },
  { rank: 7, name: "Sanjay Verma", points: 1870, badges: 7 },
  { rank: 8, name: "Kavita Reddy", points: 1790, badges: 8 },
  { rank: 9, name: "Amit Sharma", points: 1740, badges: 6 },
  { rank: 10, name: "Divya Patel", points: 1690, badges: 7 },
]

// Mock data for user's progress
const userProgress = {
  points: 850,
  rank: 42,
  badges: 5,
  challenges: {
    completed: 7,
    inProgress: 2,
    available: 4,
  },
  nextBadge: {
    name: "Innovation Champion",
    pointsNeeded: 150,
  },
}

export default function ChallengesPage() {
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold mb-4">Challenge Your Entrepreneurial Knowledge</h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Take quizzes, earn points, and unlock exclusive perks while testing your business acumen.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Available Challenges</h2>
            <div className="flex gap-2">
              <select className="px-3 py-1 rounded-md border text-sm">
                <option>All Categories</option>
                <option>Business</option>
                <option>Finance</option>
                <option>Marketing</option>
                <option>Product</option>
              </select>
              <select className="px-3 py-1 rounded-md border text-sm">
                <option>All Difficulties</option>
                <option>Beginner</option>
                <option>Intermediate</option>
                <option>Advanced</option>
              </select>
            </div>
          </div>

          <div className="space-y-6">
            {challenges.map((challenge) => (
              <Card key={challenge.id}>
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <div className="flex gap-2 mb-2">
                        <Badge>{challenge.category}</Badge>
                        <Badge
                          variant="outline"
                          className={
                            challenge.difficulty === "Beginner"
                              ? "border-green-200 text-green-700 bg-green-50 dark:bg-green-950 dark:text-green-400 dark:border-green-800"
                              : challenge.difficulty === "Intermediate"
                                ? "border-amber-200 text-amber-700 bg-amber-50 dark:bg-amber-950 dark:text-amber-400 dark:border-amber-800"
                                : "border-red-200 text-red-700 bg-red-50 dark:bg-red-950 dark:text-red-400 dark:border-red-800"
                          }
                        >
                          {challenge.difficulty}
                        </Badge>
                      </div>
                      <CardTitle>{challenge.title}</CardTitle>
                    </div>
                    <div className="flex items-center text-sm text-muted-foreground">
                      <Clock className="h-4 w-4 mr-1" />
                      <span>{challenge.timeLimit} min</span>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4">{challenge.description}</p>
                  <div className="grid grid-cols-2 gap-4 mb-4">
                    <div className="flex items-center gap-2">
                      <Users className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{challenge.participants} participants</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Trophy className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm">{challenge.questions} questions</span>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h4 className="text-sm font-medium">Perks:</h4>
                    <ul className="space-y-1">
                      {challenge.perks.map((perk, index) => (
                        <li key={index} className="text-sm flex items-start gap-2">
                          <Award className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                          <span>{perk}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between border-t pt-4">
                  <div className="text-sm text-muted-foreground">Expires in {challenge.expiresIn}</div>
                  <Link href={`/challenges/${challenge.id}`}>
                    <Button>Take Challenge</Button>
                  </Link>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
              <CardDescription>Track your achievements and ranking</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <div className="flex justify-between mb-2">
                  <span className="text-sm font-medium">Venture Points</span>
                  <span className="text-sm">{userProgress.points}</span>
                </div>
                <Progress value={85} className="h-2" />
                <div className="flex justify-between mt-1">
                  <span className="text-xs text-muted-foreground">
                    Next badge in {userProgress.nextBadge.pointsNeeded} points
                  </span>
                  <span className="text-xs text-muted-foreground">{userProgress.nextBadge.name}</span>
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 text-center">
                <div className="bg-muted rounded-md p-3">
                  <div className="text-2xl font-bold">{userProgress.rank}</div>
                  <div className="text-xs text-muted-foreground">Current Rank</div>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <div className="text-2xl font-bold">{userProgress.badges}</div>
                  <div className="text-xs text-muted-foreground">Badges Earned</div>
                </div>
                <div className="bg-muted rounded-md p-3">
                  <div className="text-2xl font-bold">{userProgress.challenges.completed}</div>
                  <div className="text-xs text-muted-foreground">Challenges Done</div>
                </div>
              </div>

              <div>
                <h3 className="text-sm font-medium mb-2">Challenge Status</h3>
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Completed</span>
                    <Badge
                      variant="outline"
                      className="bg-green-50 text-green-700 border-green-200 dark:bg-green-950 dark:text-green-400 dark:border-green-800"
                    >
                      {userProgress.challenges.completed}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">In Progress</span>
                    <Badge
                      variant="outline"
                      className="bg-amber-50 text-amber-700 border-amber-200 dark:bg-amber-950 dark:text-amber-400 dark:border-amber-800"
                    >
                      {userProgress.challenges.inProgress}
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm">Available</span>
                    <Badge variant="outline">{userProgress.challenges.available}</Badge>
                  </div>
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button variant="outline" className="w-full">
                View Your Badges
              </Button>
            </CardFooter>
          </Card>

          <div className="mt-6">
            <h3 className="text-xl font-bold mb-4">Leaderboard</h3>
            <Card>
              <CardContent className="p-0">
                <div className="divide-y">
                  {leaderboard.map((user) => (
                    <div key={user.rank} className="flex items-center justify-between p-4">
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium ${
                            user.rank <= 3
                              ? "bg-yellow-100 text-yellow-700 dark:bg-yellow-950 dark:text-yellow-400"
                              : "bg-muted text-muted-foreground"
                          }`}
                        >
                          {user.rank}
                        </div>
                        <span className="font-medium">{user.name}</span>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Trophy className="h-4 w-4 text-primary" />
                          <span className="text-sm">{user.points}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-amber-500" />
                          <span className="text-sm">{user.badges}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
              <CardFooter className="border-t">
                <Button variant="ghost" className="w-full text-sm">
                  View Full Leaderboard
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}

