import { ArrowLeft, Calendar, Clock, Users } from "lucide-react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import WebinarQASection from "@/components/webinar-qa-section"

// This would normally be fetched from a database
const getWebinarById = (id: string) => {
  const webinars = [
    {
      id: "1",
      title: "Machine Learning Fundamentals",
      description:
        "Learn the basics of machine learning algorithms and applications. This comprehensive webinar covers supervised and unsupervised learning, neural networks, and practical applications in various industries. Perfect for beginners and those looking to refresh their knowledge.",
      longDescription:
        "Machine Learning is transforming industries across the globe. In this webinar, Dr. Jane Smith will guide you through the fundamental concepts of machine learning, from basic algorithms to practical implementations. You'll learn about data preprocessing, feature engineering, model selection, and evaluation metrics. By the end of this session, you'll have a solid understanding of how machine learning works and how it can be applied to solve real-world problems.",
      date: "2025-04-15T14:00:00",
      duration: 90, // minutes
      category: "Technology",
      tags: ["AI", "Machine Learning", "Data Science"],
      speaker: {
        name: "Dr. Jane Smith",
        title: "AI Research Scientist at TechCorp",
        bio: "Dr. Jane Smith has over 15 years of experience in AI and machine learning. She has published numerous papers on neural networks and leads the AI research team at TechCorp.",
        image: "/placeholder.svg?height=100&width=100",
      },
      attendees: 245,
      agenda: [
        "Introduction to Machine Learning Concepts (15 min)",
        "Supervised vs Unsupervised Learning (20 min)",
        "Neural Networks and Deep Learning (25 min)",
        "Real-world Applications (20 min)",
        "Q&A Session (10 min)",
      ],
    },
    {
      id: "2",
      title: "Digital Marketing Strategies for 2025",
      description: "Discover the latest trends and strategies in digital marketing.",
      longDescription:
        "The digital marketing landscape is constantly evolving. This webinar will explore cutting-edge strategies that are shaping the industry in 2025. From AI-driven content creation to immersive AR/VR experiences, you'll learn how to stay ahead of the curve and maximize your marketing ROI.",
      date: "2025-04-18T10:00:00",
      duration: 60, // minutes
      category: "Marketing",
      tags: ["Digital Marketing", "SEO", "Social Media"],
      speaker: {
        name: "Mark Johnson",
        title: "CMO at MarketEdge",
        bio: "Mark Johnson is a digital marketing pioneer with expertise in SEO, content marketing, and social media strategy. He has helped numerous Fortune 500 companies transform their digital presence.",
        image: "/placeholder.svg?height=100&width=100",
      },
      attendees: 189,
      agenda: [
        "2025 Digital Marketing Trends Overview (10 min)",
        "AI-Powered Marketing Automation (15 min)",
        "Content Strategy for Modern Platforms (15 min)",
        "Measuring Success: Analytics & KPIs (10 min)",
        "Q&A Session (10 min)",
      ],
    },
    // Additional webinars would be here
  ]

  return webinars.find((webinar) => webinar.id === id)
}

export default function WebinarPage({ params }: { params: { id: string } }) {
  const webinar = getWebinarById(params.id)

  if (!webinar) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-3xl font-bold mb-4">Webinar Not Found</h1>
        <p className="mb-8">The webinar you're looking for doesn't exist or has been removed.</p>
        <Link href="/">
          <Button>Return to Home</Button>
        </Link>
      </div>
    )
  }

  const formattedDate = new Date(webinar.date).toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "numeric",
    year: "numeric",
  })

  const formattedTime = new Date(webinar.date).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })

  return (
    <main className="container mx-auto px-4 py-8">
      <Link href="/" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6">
        <ArrowLeft className="mr-2 h-4 w-4" />
        Back to all webinars
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <div className="mb-6">
            <div className="flex flex-wrap gap-2 mb-3">
              <Badge>{webinar.category}</Badge>
              {webinar.tags.map((tag) => (
                <Badge key={tag} variant="outline">
                  {tag}
                </Badge>
              ))}
            </div>
            <h1 className="text-4xl font-bold mb-4">{webinar.title}</h1>
            <p className="text-xl text-muted-foreground">{webinar.description}</p>
          </div>

          <Tabs defaultValue="about">
            <TabsList className="mb-6">
              <TabsTrigger value="about">About</TabsTrigger>
              <TabsTrigger value="agenda">Agenda</TabsTrigger>
              <TabsTrigger value="qa">Q&A</TabsTrigger>
            </TabsList>

            <TabsContent value="about" className="space-y-6">
              <div>
                <h2 className="text-2xl font-semibold mb-3">About This Webinar</h2>
                <p className="text-muted-foreground">{webinar.longDescription}</p>
              </div>

              <div>
                <h2 className="text-2xl font-semibold mb-3">Speaker</h2>
                <div className="flex items-start gap-4">
                  <img
                    src={webinar.speaker.image || "/placeholder.svg"}
                    alt={webinar.speaker.name}
                    className="rounded-full w-16 h-16 object-cover"
                  />
                  <div>
                    <h3 className="font-semibold text-lg">{webinar.speaker.name}</h3>
                    <p className="text-muted-foreground mb-2">{webinar.speaker.title}</p>
                    <p className="text-sm">{webinar.speaker.bio}</p>
                  </div>
                </div>
              </div>
            </TabsContent>

            <TabsContent value="agenda">
              <h2 className="text-2xl font-semibold mb-4">Webinar Agenda</h2>
              <ol className="space-y-4">
                {webinar.agenda.map((item, index) => (
                  <li key={index} className="flex gap-4">
                    <span className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-primary text-primary-foreground font-medium">
                      {index + 1}
                    </span>
                    <div className="pt-1">{item}</div>
                  </li>
                ))}
              </ol>
            </TabsContent>

            <TabsContent value="qa">
              <WebinarQASection webinarId={webinar.id} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-1">
          <div className="bg-muted rounded-lg p-6 sticky top-6">
            <h2 className="text-xl font-semibold mb-6">Webinar Details</h2>

            <div className="space-y-4 mb-6">
              <div className="flex items-start gap-3">
                <Calendar className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium">Date & Time</p>
                  <p className="text-muted-foreground">{formattedDate}</p>
                  <p className="text-muted-foreground">{formattedTime}</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium">Duration</p>
                  <p className="text-muted-foreground">{webinar.duration} minutes</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Users className="h-5 w-5 text-muted-foreground mt-0.5" />
                <div>
                  <p className="font-medium">Attendees</p>
                  <p className="text-muted-foreground">{webinar.attendees} people registered</p>
                </div>
              </div>
            </div>

            <Button className="w-full mb-3" size="lg">
              Register Now
            </Button>
            <Button variant="outline" className="w-full">
              Add to Calendar
            </Button>
          </div>
        </div>
      </div>
    </main>
  )
}

