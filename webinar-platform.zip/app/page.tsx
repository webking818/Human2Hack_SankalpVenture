import Link from "next/link"
import { Search, Lightbulb, Users, Trophy, BookOpen } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import FeaturedMentors from "@/components/featured-mentors"
import TrendingProjects from "@/components/trending-projects"
import NewsRecommendations from "@/components/news-recommendations"
import UpcomingWebinars from "@/components/upcoming-webinars"

export default function Home() {
  return (
    <main className="container mx-auto px-4 py-8">
      <section className="mb-12">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4">Welcome to Sankalp Venture</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Connect with like-minded entrepreneurs, find mentors, and discover projects that match your interests.
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 max-w-3xl mx-auto">
          <div className="relative flex-grow">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search projects, mentors, or topics" className="pl-10" />
          </div>
          <Button>Explore</Button>
        </div>
      </section>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
        <Card className="bg-primary/5 border-primary/20">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <CardTitle className="text-lg">Connect</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Find and connect with entrepreneurs who share your interests and goals.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/connections" className="text-sm font-medium text-primary">
              Find Connections →
            </Link>
          </CardFooter>
        </Card>

        <Card className="bg-orange-50 border-orange-200 dark:bg-orange-950 dark:border-orange-800">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Lightbulb className="h-5 w-5 text-orange-500 dark:text-orange-400" />
              <CardTitle className="text-lg">Projects</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Discover innovative projects or share your own to get feedback and collaborators.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/projects" className="text-sm font-medium text-orange-600 dark:text-orange-400">
              Explore Projects →
            </Link>
          </CardFooter>
        </Card>

        <Card className="bg-emerald-50 border-emerald-200 dark:bg-emerald-950 dark:border-emerald-800">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-emerald-500 dark:text-emerald-400" />
              <CardTitle className="text-lg">Challenges</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Test your knowledge with quizzes, earn perks, and climb the leaderboard.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/challenges" className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
              Take a Challenge →
            </Link>
          </CardFooter>
        </Card>

        <Card className="bg-blue-50 border-blue-200 dark:bg-blue-950 dark:border-blue-800">
          <CardHeader className="pb-2">
            <div className="flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-blue-500 dark:text-blue-400" />
              <CardTitle className="text-lg">Mentorship</CardTitle>
            </div>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Connect with experienced mentors by sharing your project ideas.
            </p>
          </CardContent>
          <CardFooter>
            <Link href="/mentors" className="text-sm font-medium text-blue-600 dark:text-blue-400">
              Find Mentors →
            </Link>
          </CardFooter>
        </Card>
      </section>

      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Trending Projects</h2>
          <Link href="/projects">
            <Button variant="outline" size="sm">
              View All
            </Button>
          </Link>
        </div>
        <TrendingProjects />
      </section>

      <section className="mb-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Featured Mentors</h2>
          <Link href="/mentors">
            <Button variant="outline" size="sm">
              View All
            </Button>
          </Link>
        </div>
        <FeaturedMentors />
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="lg:col-span-2">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Upcoming Webinars</h2>
            <Link href="/webinars">
              <Button variant="outline" size="sm">
                View All
              </Button>
            </Link>
          </div>
          <UpcomingWebinars />
        </div>

        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">News For You</h2>
            <Link href="/news">
              <Button variant="outline" size="sm">
                More
              </Button>
            </Link>
          </div>
          <NewsRecommendations />
        </div>
      </div>

      <section className="bg-muted p-8 rounded-lg">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-4">Ready to Start Your Entrepreneurial Journey?</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Join Sankalp Venture today to connect with mentors, discover projects, and grow your entrepreneurial skills.
          </p>
        </div>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button size="lg">Sign Up Now</Button>
          <Button variant="outline" size="lg">
            Learn More
          </Button>
        </div>
      </section>
    </main>
  )
}

